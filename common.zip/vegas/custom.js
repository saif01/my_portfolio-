(function($){
$('.vegas-slider').vegas({
transition:'fade',
slides: [
        { src: "images/vagas/slider (1).jpg" },
        { src: "images/vagas/slider (2).jpg" },
        { src: "images/vagas/slider (3).jpg" },
        { src: "images/vagas/slider (4).jpg" }
    ], animation: 'random',
    overlay: 'pluagins/vegus/overlays/09.png',
});

})(jQuery);