<?php
// For Hardware Address.
$ADDRESS="<address> 
           <b> Support Team: </b><br>
           <font size='2' color='#1E90FF'>
            Md. Moniruzzaman <br>
            Contract: 01787 692 529<br>
            Md. Polash Mahamud <br>
            Contract: 01787 692 530<br>
       
            Holding No: E-236, Ward No: 007 <br>
            Chandra, Kaliyakor, Gazipur <br>
            </font>
            <font size='2'> Thank you.</font><br>
            </address>" ;

// For Application Address.
$APP_ADDRESS="<address> 
           <b> Support Team: </b><br>
           <font size='2' color='#1E90FF'>
            Md.Abul Kalam Azad <br> 
            Contract: 01766 668 845 <br>
            Md.Abdulla Al Hadi <br> 
            Contract: 01750 687 227 <br>
            Holding No: E-236, Ward No: 007 <br>
            Chandra, Kaliyakor, Gazipur <br>
            </font>
            <font size='2'> Thank you.</font><br>
            </address>" ;


?>