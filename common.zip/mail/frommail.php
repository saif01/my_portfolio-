<?php
	define('FROM_MAIL', 'saifulislamw60@gmail.com');
	define('PASS', 'SAIFULislam$25');

	
	
?>